"""One-time primary-release pin capture; not part of the build gate."""
import hashlib
import importlib.metadata
import io
import json
import difflib
from pathlib import Path
import subprocess
import urllib.request
import tarfile
import tomllib
from packaging.tags import cpython_tags, compatible_tags
from packaging.utils import parse_wheel_filename, canonicalize_name
from packaging.requirements import Requirement

OUT = Path('/tmp/nsealr-h01-portable-origins')
REPO = Path('/home/tux/nsealr/.restart-tools/goal/h01-s3-bod-portable')
SDK = Path('/home/tux/nsealr/.restart-tools/goal/h01-s3-bod-source-gate-runtime/esp-idf')
TOOLS = REPO / 'diagnostics/s3-bod-selector/tools'


def read_url(url, name):
    path = OUT / name
    if path.exists():
        return path.read_bytes()
    req = urllib.request.Request(url, headers={'User-Agent': 'nSealr-H01-source-pin/1'})
    try:
        with urllib.request.urlopen(req, timeout=60) as response:
            data = response.read()
        path.write_bytes(data)
        return data
    except Exception as exc:
        (OUT / (name + '.error.json')).write_text(json.dumps({'url': url, 'error': repr(exc)}) + '\n')
        raise


def main():
    TOOLS.mkdir(exist_ok=True)
    platforms = ['manylinux_2_%d_x86_64' % n for n in range(34, 4, -1)] + ['manylinux2014_x86_64', 'manylinux2010_x86_64', 'manylinux1_x86_64']
    tags = list(cpython_tags((3, 12), ['cp312'], platforms)) + list(compatible_tags((3, 12), 'cp312', platforms))
    rank = {tag: index for index, tag in reversed(list(enumerate(tags)))}
    profile = json.loads((REPO / 'docs/restart/H01/checks/s3-bod-mode0-first-build-2026-10-23/producer-bindings.json').read_text())['Python_environment_packages']
    assert len(profile) == 63
    packages = []
    for item in profile:
        name = canonicalize_name(item['name'])
        version = '50.0.0' if name == 'cryptography' else item['version']
        url = 'https://pypi.org/pypi/%s/%s/json' % (name, version)
        raw = read_url(url, 'pypi-%s-%s.json' % (name, version))
        if name == 'cryptography':
            assert hashlib.sha256(raw).hexdigest() == '4cb03a11a6a704310e9aab006acf6d4946c1543f0f8410d7188b90ec1e17f03d'
        metadata = json.loads(raw)
        assert canonicalize_name(metadata['info']['name']) == name and metadata['info']['version'] == version
        candidates = []
        for entry in metadata['urls']:
            if entry['packagetype'] != 'bdist_wheel' or entry['yanked']:
                continue
            parsed_name, parsed_version, _, wheel_tags = parse_wheel_filename(entry['filename'])
            assert canonicalize_name(parsed_name) == name and str(parsed_version) == version
            compatible = wheel_tags & rank.keys()
            if compatible:
                candidates.append((min(rank[tag] for tag in compatible), entry['filename'], entry))
        if candidates:
            selected = min(candidates)[2]
            source_build = None
        else:
            sdists = [entry for entry in metadata['urls'] if entry['packagetype'] == 'sdist' and not entry['yanked']]
            assert len(sdists) == 1, ('Missing unambiguous exact-version primary distribution; stop', name, version)
            selected = sdists[0]
            body = read_url(selected['url'], selected['filename'])
            assert hashlib.sha256(body).hexdigest() == selected['digests']['sha256']
            with tarfile.open(fileobj=io.BytesIO(body), mode='r:gz') as tar:
                declarations = [member for member in tar.getmembers() if member.isfile() and member.name.count('/') == 1 and member.name.endswith('/pyproject.toml')]
                assert len(declarations) == 1, ('Need explicit reviewed source build-system', name, version)
                declaration = tar.extractfile(declarations[0]).read()
            system = tomllib.loads(declaration.decode())['build-system']
            frozen_versions = {canonicalize_name(row['name']): row['version'] for row in profile}
            for text in system['requires']:
                requirement = Requirement(text)
                assert canonicalize_name(requirement.name) in frozen_versions and frozen_versions[canonicalize_name(requirement.name)] in requirement.specifier, ('Unpinned source-build dependency; stop', name, text)
            source_build = {'pyproject_path': declarations[0].name, 'pyproject_sha256': hashlib.sha256(declaration).hexdigest(), 'build_system': system, 'backend_dependencies_already_in_frozen_profile': True}
        assert selected['url'].startswith('https://files.pythonhosted.org/')
        packages.append({'name': name, 'version': version, 'filename': selected['filename'], 'kind': selected['packagetype'], 'url': selected['url'], 'sha256': selected['digests']['sha256'], 'bytes': selected['size'], 'requires_python': selected['requires_python'], 'publisher_metadata_url': url, 'publisher_metadata_sha256': hashlib.sha256(raw).hexdigest(), 'yanked_at_capture': selected['yanked'], 'published_vulnerabilities_at_capture': metadata.get('vulnerabilities', []), 'source_build': source_build})
    nonwithdrawn = {item['name']: [row for row in item['published_vulnerabilities_at_capture'] if not row.get('withdrawn')] for item in packages}
    nonwithdrawn = {name: rows for name, rows in nonwithdrawn.items() if rows}
    (OUT / 'corrected-profile-advisory-summary.json').write_text(json.dumps({'profile_count': len(packages), 'metadata_only_before_install': True, 'nonwithdrawn_advisories': nonwithdrawn, 'changed_version_only': {'cryptography': ['48.0.1', '50.0.0']}, 'source_metadata': [{'name': item['name'], 'version': item['version'], 'url': item['publisher_metadata_url'], 'sha256': item['publisher_metadata_sha256']} for item in packages]}, indent=2) + '\n')
    assert not nonwithdrawn, 'Aggregate primary profile advisory result needs adjudication before use'
    baseline = json.loads(subprocess.check_output(['git', '-C', '/home/tux/nsealr/firmware', 'show', '592a412b17bff42f496f8785c36ec18bfc0ac4f8:tools/baseline/inputs.json']))
    python = baseline['tools']['python']
    old_assets = json.loads((REPO / 'docs/restart/H01/checks/s3-bod-build-blocker-2026-10-23/tool-downloads.json').read_text())
    assets = []
    for row in old_assets:
        assets.append({'name': row['name'], 'version': row['version'], 'filename': Path(row['argv'][row['argv'].index('--output') + 1]).name, **row['asset'], 'publisher_pin': 'fff9895c82d744c7237be8847347bdd1b07c6643:tools/tools.json'})
    release = json.loads((OUT / 'cmake-release.json').read_text())
    cmake = [item for item in release['assets'] if item['name'] == 'cmake-3.31.6-linux-x86_64.tar.gz'][0]
    sums = (OUT / 'cmake-3.31.6-SHA-256.txt').read_bytes()
    cmake_hash = [line.split()[0] for line in sums.decode().splitlines() if line.endswith(cmake['name'])]
    assert len(cmake_hash) == 1
    assets.append({'name': 'cmake', 'version': '3.31.6', 'filename': cmake['name'], 'url': cmake['browser_download_url'], 'size': cmake['size'], 'sha256': cmake_hash[0], 'publisher_pin': 'https://github.com/Kitware/CMake/releases/download/v3.31.6/cmake-3.31.6-SHA-256.txt', 'publisher_checksum_body_sha256': hashlib.sha256(sums).hexdigest()})
    assets.append({'name': 'python', **python, 'publisher_pin': '592a412b17bff42f496f8785c36ec18bfc0ac4f8:tools/baseline/inputs.json; existing authenticated R00 primary asset pin'})
    inputs = json.loads((REPO / 'docs/restart/H01/s3-bod-tee-default-amendment.json').read_text())['current_project_inputs']
    core_inputs = [{'path': row['path'], 'sha256': row['current_sha256']} for row in inputs]
    constraints = Path('/home/tux/nsealr/.restart-tools/goal/h01-s3-bod-source-gate-runtime/idf-tools/espidf.constraints.v6.1.txt').read_bytes()
    primary_constraints = read_url('https://dl.espressif.com/dl/esp-idf/espidf.constraints.v6.1.txt', 'espidf.constraints.v6.1.txt')
    assert primary_constraints == constraints, 'Exact working SDK constraints differ from current primary body; stop before build'
    assert constraints.count(b'cryptography>=2.1.4,<49\n') == 1
    corrected = constraints.replace(b'cryptography>=2.1.4,<49\n', b'cryptography==50.0.0\n')
    (TOOLS / 'espidf.constraints.v6.1.upstream.txt').write_bytes(constraints)
    (TOOLS / 'espidf.constraints.v6.1.txt').write_bytes(corrected)
    patch = ''.join(difflib.unified_diff(constraints.decode().splitlines(True), corrected.decode().splitlines(True), fromfile='espidf.constraints.v6.1.upstream.txt', tofile='espidf.constraints.v6.1.txt'))
    (TOOLS / 'cryptography-50.patch').write_text(patch)
    lock = {'schema_version': 1, 'host_scope': 'Linux x86_64; exact compiler/tools/Python assets and CPython3.12 distributions selected for manylinux<=2.34 or pure Python; no ARM/Pi/physical claim', 'SDK': {'url': 'https://github.com/espressif/esp-idf.git', 'commit': 'fff9895c82d744c7237be8847347bdd1b07c6643', 'tree': 'e6a5e4865e2027f1f0cef5da09f254d65c5cec22', 'Gitlinks': json.loads((OUT / 'selected-gitlinks.json').read_text())}, 'project_inputs': core_inputs, 'assets': assets, 'Python_packages': packages, 'SDK_constraints': {'filename': 'espidf.constraints.v6.1.txt', 'sha256': hashlib.sha256(corrected).hexdigest(), 'upstream_filename': 'espidf.constraints.v6.1.upstream.txt', 'upstream_sha256': hashlib.sha256(constraints).hexdigest(), 'patch_filename': 'cryptography-50.patch', 'patch_sha256': hashlib.sha256(patch.encode()).hexdigest(), 'source': 'Locally maintained one-line corrective compatibility profile admitted by b569f561cdc5287475d11125a6a455bb9dd3cb87. Not upstream-supported or a security/reproducibility qualification; strict upstream negative/patched positive/pip check required.'}, 'pin_meaning': 'Working-profile versions select exact releases except admitted cryptography50 correction; publisher release metadata and distribution SHA-256 authenticate selected archive bytes. Installed RECORD is not the authority. Derived esptool wheel is a local build from authenticated sdist, not a publisher wheel. No release-signature, ecosystem freshness or reproducibility claim.'}
    (TOOLS / 'inputs.json').write_text(json.dumps(lock, indent=2) + '\n')
    (TOOLS / 'python-versions.txt').write_text(''.join('%s==%s\n' % (row['name'], row['version']) for row in packages))
    print(json.dumps({'packages': len(packages), 'assets': len(assets), 'Gitlinks': len(lock['SDK']['Gitlinks']), 'input_lock_sha256': hashlib.sha256((TOOLS / 'inputs.json').read_bytes()).hexdigest()}))


if __name__ == '__main__':
    main()
